//
// CLIENTE DE CONTA BANCÁRIA SIMPLES
//
// Sistemas Distribuídos
// Escola Politécnica -- PUCPR
// (C) Prof. Luiz Lima Jr. (luiz.lima@pucpr.br)
//

#include <iostream>
#include <string>
#include <ContaC.h>

using namespace std;
using namespace CORBA;

int main(int argc, char* argv[])
{
    if (argc < 2) {
        cerr << "Faltou parametro!\n";
        cerr << argv[0] << " <ior>\n";
        return 1;
    }

    try {
	    // 1. Inicializa ORB
        ORB_var orb = ORB_init(argc, argv, "ORB");

	    // 2. Obtém referência para objeto distirbuído (da IOR)
        Object_ptr ref = orb->string_to_object(argv[1]);
        Conta_var conta = Conta::_narrow(ref);

	    // 3. Usa objeto (chama métodos)
        
        cout << "identificador da conta: " << conta->id() << '\n';

        float valor;
        cout << "Valor para deposito: ";
        cin >> valor;

        cout << "deposito(" << valor << ")\n";
        conta->deposito(valor);
        try {
            cout << "Valor para saque: ";
            cin >> valor;
            cout << "saque(" << valor << ")\n";
            conta->saque(valor);
        } catch (const SaldoInsuficiente& ) {
            cerr << "saldo insuficiente!\n";
        }

        cout << "saldo: " << conta->saldo() << endl;

        string resp;
        cout << "shutdown? (s/n) ";
        cin >> resp;
        if (resp == "s")
            conta->shutdown("123");

	    // 4. Finalizações
        orb->destroy();
    } catch (const Exception& e) {
        cerr << "ERRO CORBA: " << e << endl;
    }
}
