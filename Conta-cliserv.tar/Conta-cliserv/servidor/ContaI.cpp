#include "ContaI.h"
#include <iostream>

using namespace std;

extern CORBA::ORB_var orb;  // definido em servidor.cpp

// Implementation skeleton constructor
Conta_i::Conta_i ()
{
    meu_saldo = 0.0;
    identif = "12345-67";
}

// Implementation skeleton destructor
Conta_i::~Conta_i ()
{
}

std::string Conta_i::id ()
{
    cout << identif << ": retonando identificador\n";
    return identif;
}

::CORBA::Float Conta_i::saldo ()
{
    cout << identif << ": retornando saldo\n";
    return meu_saldo;
}

void Conta_i::deposito (::CORBA::Float valor)
{
    meu_saldo += valor;
    cout << identif << ": deposito(" << valor << ")\n";
}

void Conta_i::saque (::CORBA::Float valor)
{
    cout << identif << ": saque";
    if (valor <= meu_saldo) {
        meu_saldo -= valor;
        cout << "(" << valor << ")\n";
    } else {
        cout << " - saldo insuficiente\n";
        throw SaldoInsuficiente();
    }
}

void Conta_i::transfere (
  ::CORBA::Float valor,
  ::Conta_ptr dest)
{
    saque(valor);
    dest->deposito(valor);
}

void Conta_i::shutdown (const std::string senha)
{
    if (senha == "123")
        orb->shutdown();
}

