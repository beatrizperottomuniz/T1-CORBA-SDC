//
// SERVIDOR DE CONTA SIMPLES
// Sistemas Distribuídos
// Escola Politécnica -- PUCPR
// (C) Prof. Luiz Lima Jr. (luiz.lima@pucpr.br)
//

#include <iostream>
#include <fstream>
#include <string>
#include "ContaI.h"

using namespace std;
using namespace CORBA;
using namespace PortableServer;

ORB_var orb;   // define global para poder ser acessado por Conta_i p/ shutdown

int main(int argc, char* argv[])
{
    try {
	    // 1. Inicia ORB
        orb = ORB_init(argc, argv, "ORB");

	    // 2. Ativa RootPOA
        Object_ptr aux;
        aux = orb->resolve_initial_references("RootPOA");
        POA_var poa = POA::_narrow(aux);
        POAManager_var ger = poa->the_POAManager();
        ger->activate();

	    // 3. Instancia "servants"
        Conta_i ci;
	
        // 4. Registra servos no POA, criando objetos distribuídos
        Conta_var conta = ci._this();
	    
        // 5. Publica IOR
        string ior = orb->object_to_string(conta.in());
        ofstream("conta.ior") << ior;
        cout << "IOR publicada em conta.ior\n";

	    // 6. Aguarda requisições
        cout << "aguardando requisicoes\n";
        orb->run();

	    // 7. Finalizações
        cout << "terminando servidor\n";
        poa->destroy(true,true);
        orb->destroy();
    } catch (const Exception& e) {
        cerr << "ERRO CORBA: " << e << '\n';
    }
}
