#include <iostream>
#include <string>
#include <CEtcdC.h>
#include <orbsvcs/CosNamingC.h>

using namespace std;
using namespace CORBA;

int main(int argc, char* argv[])
{
    if (argc < 2) {
        cerr << "Uso:\n";
        cerr << "  " << argv[0] << " id\n";
        cerr << "  " << argv[0] << " get <key>\n";
        cerr << "  " << argv[0] << " del <key>\n";
        cerr << "  " << argv[0] << " put <key> <val>\n";
        return 1;
    }

	try{
		// 1. Inicializa ORB
		ORB_var orb = ORB_init(argc, argv, "ORB");

		// 2. busca objeto pelo NS
		Object_ptr ns_obj = orb->resolve_initial_references("NameService");
		CosNaming::NamingContext_var ns = CosNaming::NamingContext::_narrow(ns_obj);

		CosNaming::Name name;
		name.length(1);
		name[0].id = CORBA::string_dup("CEtcd");

		Object_ptr ref = ns->resolve(name);
		CEtcd_var etcd = CEtcd::_narrow(ref);

		string op = argv[1];

		if (op == "id") {
			cout << etcd->id() << "\n";

		} else if (op == "get") {
			if (argc < 3) { cerr << "Faltou a chave\n"; return 1; }
			try {
				cout << etcd->get(argv[2]) << "\n";
			} catch (const InvalidKey&) {
				cerr << "Erro - chave " << argv[2] << " nao encontrada\n";
			}

		} else if (op == "del") {
			if (argc < 3) { cerr << "Faltou a chave\n"; return 1; }
			try {
				etcd->del(argv[2]);
				cout << "Chave " << argv[2] << " removida\n";
			} catch (const InvalidKey&) {
				cerr << "Erro - chave " << argv[2] << " nao encontrada\n";
			}

		} else if (op == "put") {
			if (argc < 4) { cerr << "Faltou chave ou valor\n"; return 1; }
			bool nova = etcd->put(argv[2], argv[3]);
			if (nova)
				cout << "Chave " << argv[2] << " inserida\n";
			else
				cout << "Chave " << argv[2] << " atualizada\n";

		} else {
			cerr << "operacao desconhecida: " << op << "\n";
			return 1;
		}

		orb->destroy();
    } catch (const Exception& e) {
        cerr << "ERRO CORBA: " << e << endl;
    }
}
