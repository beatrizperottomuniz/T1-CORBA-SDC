// -*- C++ -*-
// TAO_IDL - Generated from
// /opt/ACE_wrappers/TAO/TAO_IDL/be/be_codegen.cpp:1621

#include "CEtcdI.h"
#include <iostream>

using namespace std;

// Implementation skeleton constructor
CEtcd_i::CEtcd_i ()
{
	identif_ = "CEtcd-obj-1";
    cout << "id do servidor = " << identif_ << "\n";
}

// Implementation skeleton destructor
CEtcd_i::~CEtcd_i ()
{
}

std::string CEtcd_i::id ()
{
    cout << "id() = " << identif_ << "\n";
    return identif_;
}

::CORBA::Boolean CEtcd_i::put (
  const std::string key,
  const std::string val)
{
    bool nova = (tabela_.find(key) == tabela_.end());
    tabela_[key] = val;

    if (nova) {
        cout << "put(" << key << "," << val << ") - chave nova\n";
    } else {
        cout << "put(" << key << "," << val << ") - chave atualizada\n";
    }

    return nova;// true = nova, false = ja existe
}

std::string CEtcd_i::get (
  const std::string key)
{
    auto it = tabela_.find(key);
    if (it == tabela_.end()) {
        cout << "get(" << key << ") - chave nao encontrada\n";
        throw InvalidKey();
    }
    cout << "get(" << key << ") - " << it->second << "\n";
    return it->second;
}

void CEtcd_i::del (
  const std::string key)
{
    auto it = tabela_.find(key);
    if (it == tabela_.end()) {
        cout << "del(" << key << ") - chave nao encontrada\n";
        throw InvalidKey();
    }
    tabela_.erase(it);
    cout << "del(" << key << ") - removida com sucesso\n";
}

