// -*- C++ -*-
// TAO_IDL - Generated from
// /opt/ACE_wrappers/TAO/TAO_IDL/be/be_codegen.cpp:1567

#ifndef CETCDI_G0X0P0_H_
#define CETCDI_G0X0P0_H_

#include "CEtcdS.h"
#include <map>

#if !defined (ACE_LACKS_PRAGMA_ONCE)
#pragma once
#endif /* ACE_LACKS_PRAGMA_ONCE */

class  CEtcd_i
  : public virtual POA_CEtcd
{
public:
  // Constructor
  CEtcd_i ();

  // Destructor
  virtual ~CEtcd_i ();

  virtual std::string id ();
  virtual ::CORBA::Boolean put (const std::string key, const std::string val);
  virtual std::string get (const std::string key);
  virtual void del (const std::string key);
  
private:
    std::string identif_;
    std::map<std::string, std::string> tabela_;  // tabela de chave/valor
};


#endif /* CETCDI_H_  */
