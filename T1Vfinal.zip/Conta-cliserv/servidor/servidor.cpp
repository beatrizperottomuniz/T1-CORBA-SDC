#include <iostream>
#include <string>
#include "CEtcdI.h"

#include <orbsvcs/CosNamingC.h>

using namespace std;
using namespace CORBA;
using namespace PortableServer;

ORB_var orb;

int main(int argc, char* argv[])
{
    try {
        // 1. Inicia o ORB
        orb = ORB_init(argc, argv, "ORB");

        // 2. Ativa o RootPOA
        Object_ptr aux = orb->resolve_initial_references("RootPOA");
        POA_var poa = POA::_narrow(aux);
        POAManager_var ger = poa->the_POAManager();
        ger->activate();

        // 3. Instancia o servant
        CEtcd_i servant;

        // 4. Registra servos no POA, criando objetos distribuídos
        CEtcd_var cetcd = servant._this();

        // 5. Publica no Name Service=cliente pode buscar pelo nome "CEtcd"
		Object_ptr ns_obj = orb->resolve_initial_references("NameService");
		CosNaming::NamingContext_var ns =
			CosNaming::NamingContext::_narrow(ns_obj);

		CosNaming::Name name;
		name.length(1);
		name[0].id   = CORBA::string_dup("CEtcd");
		ns->rebind(name, cetcd.in());
		
	    // 6. Aguarda requisições
        cout << "aguardando requisicoes\n";
        orb->run();

	    // 7. Finalizações
        cout << "terminando servidor\n";
        poa->destroy(true,true);
        orb->destroy();
    } catch (const Exception& e) {
        cerr << "ERRO CORBA: " << e << '\n';
    }

    return 0;
}
